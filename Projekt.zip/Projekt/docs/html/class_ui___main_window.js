var class_ui___main_window =
[
    [ "retranslateUi", "class_ui___main_window.html#a097dd160c3534a204904cb374412c618", null ],
    [ "setupUi", "class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58", null ],
    [ "centralwidget", "class_ui___main_window.html#a356f1cf3ebda15f1fac59467ee081b74", null ],
    [ "menubar", "class_ui___main_window.html#adf43d9a67adaec750aaa956b5e082f09", null ],
    [ "statusbar", "class_ui___main_window.html#a1687cceb1e2787aa1f83e50433943a91", null ]
];