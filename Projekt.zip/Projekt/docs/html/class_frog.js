var class_frog =
[
    [ "Frog", "class_frog.html#a2873f4183ed7d9d47736b9c36b0d0d0d", null ],
    [ "clean", "class_frog.html#a82d38a27e3dc849c20214b991abdf9f9", null ],
    [ "feed", "class_frog.html#adfe5c01f8adbbc59c071aca63a31e83f", null ],
    [ "getType", "class_frog.html#aa36606dc69241b3c675d4f7dfbee3da5", null ],
    [ "play", "class_frog.html#af6f396343a91e72497ff39a1ff0f2e0e", null ],
    [ "sleep", "class_frog.html#a0ff33aa3a02c0e3a3e2f0ba11f162985", null ]
];