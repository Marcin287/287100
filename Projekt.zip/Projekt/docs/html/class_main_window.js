var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "stack", "class_main_window.html#ad1eef01717c9576331c392e772ce0e8b", null ]
];