var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "cat.cpp", "cat_8cpp.html", null ],
    [ "cat.h", "cat_8h.html", "cat_8h" ],
    [ "choosepet.cpp", "choosepet_8cpp.html", null ],
    [ "choosepet.h", "choosepet_8h.html", "choosepet_8h" ],
    [ "dog.cpp", "dog_8cpp.html", null ],
    [ "dog.h", "dog_8h.html", "dog_8h" ],
    [ "frog.cpp", "frog_8cpp.html", null ],
    [ "frog.h", "frog_8h.html", "frog_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "orange.cpp", "orange_8cpp.html", null ],
    [ "orange.h", "orange_8h.html", "orange_8h" ],
    [ "pet.cpp", "pet_8cpp.html", null ],
    [ "pet.h", "pet_8h.html", "pet_8h" ],
    [ "petroom.cpp", "petroom_8cpp.html", null ],
    [ "petroom.h", "petroom_8h.html", "petroom_8h" ],
    [ "splashscreen.cpp", "splashscreen_8cpp.html", null ],
    [ "splashscreen.h", "splashscreen_8h.html", "splashscreen_8h" ]
];