var class_cat =
[
    [ "Cat", "class_cat.html#a4253ddeabecca7dab6e82b3db5e52c6d", null ],
    [ "clean", "class_cat.html#a379ef61e747a17659f2c7b617c77879b", null ],
    [ "feed", "class_cat.html#a08421afd76d4232e9c786f1812c7dc84", null ],
    [ "getType", "class_cat.html#af3965d0724f240c8c67116239de9cdc2", null ],
    [ "play", "class_cat.html#ae2b5ae1086dd03bbdb2c9061075b4c88", null ],
    [ "sleep", "class_cat.html#a8e6f4cbb9306c5c16a2f3c7e9c7ac8e4", null ]
];