var class_dog =
[
    [ "Dog", "class_dog.html#a952bdeae87103b7d7d25b7544ccdfcd7", null ],
    [ "clean", "class_dog.html#aceb32b260c1eb1d825d853e5faf8b882", null ],
    [ "feed", "class_dog.html#a1ba4825eb508b290d4d5a3111e9a9452", null ],
    [ "getType", "class_dog.html#a6b4cea25920cceeb642f6b5c11634a49", null ],
    [ "play", "class_dog.html#af6a16e68d04f2008669e484f988174e7", null ],
    [ "sleep", "class_dog.html#a9670535c549881f9ff6925adb351f6cf", null ]
];