var annotated_dup =
[
    [ "QT_WARNING_DISABLE_DEPRECATED", "namespace_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d.html", [
      [ "qt_meta_tag_ZN10MainWindowE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n10_main_window_e__t.html", null ],
      [ "qt_meta_tag_ZN12SplashScreenE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n12_splash_screen_e__t.html", null ],
      [ "qt_meta_tag_ZN13PetRoomWidgetE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n13_pet_room_widget_e__t.html", null ],
      [ "qt_meta_tag_ZN15ChoosePetWidgetE_t", "struct_q_t___w_a_r_n_i_n_g___d_i_s_a_b_l_e___d_e_p_r_e_c_a_t_e_d_1_1qt__meta__tag___z_n15_choose_pet_widget_e__t.html", null ]
    ] ],
    [ "Ui", "namespace_ui.html", [
      [ "MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Cat", "class_cat.html", "class_cat" ],
    [ "ChoosePetWidget", "class_choose_pet_widget.html", "class_choose_pet_widget" ],
    [ "Dog", "class_dog.html", "class_dog" ],
    [ "Frog", "class_frog.html", "class_frog" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Orange", "class_orange.html", "class_orange" ],
    [ "Pet", "class_pet.html", "class_pet" ],
    [ "PetRoomWidget", "class_pet_room_widget.html", "class_pet_room_widget" ],
    [ "SplashScreen", "class_splash_screen.html", "class_splash_screen" ],
    [ "Ui_MainWindow", "class_ui___main_window.html", "class_ui___main_window" ]
];