var class_orange =
[
    [ "Orange", "class_orange.html#a1dd234287f986ec330eeda9ceb2c0f60", null ],
    [ "clean", "class_orange.html#ae18604684fc4a520ce47166587929390", null ],
    [ "feed", "class_orange.html#aa3d21bf54902fe290996a7155a012726", null ],
    [ "getType", "class_orange.html#a526324a89dafbebd51a02de2fa63e5fd", null ],
    [ "play", "class_orange.html#a0c8ced4d3b1e847c8f6aa888fcf98d68", null ],
    [ "sleep", "class_orange.html#ae3772aa9cc0eea84a12b7a03344997d3", null ]
];