var searchData=
[
  ['mingw_5fhas_5fsecure_5fapi_0',['MINGW_HAS_SECURE_API',['../moc__predefs_8h.html#a7652218632d79c675cce0c49732ee345',1,'moc_predefs.h']]]
];
