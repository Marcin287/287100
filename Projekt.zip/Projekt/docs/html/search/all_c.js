var searchData=
[
  ['name_0',['name',['../class_pet.html#a20631567e9dd49f8d8bb9f95b3d976f8',1,'Pet']]],
  ['nameedit_1',['nameEdit',['../class_choose_pet_widget.html#afb99585ee3f3f547727d51db7c41905b',1,'ChoosePetWidget']]],
  ['namelabel_2',['nameLabel',['../class_pet_room_widget.html#ab94e8c68f26b7d68a05111fafcf91f0f',1,'PetRoomWidget']]],
  ['nextbutton_3',['nextButton',['../class_choose_pet_widget.html#aa2dfc1cb22e051a3e8c17e68a7b479ec',1,'ChoosePetWidget']]]
];
