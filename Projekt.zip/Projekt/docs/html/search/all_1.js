var searchData=
[
  ['age_0',['age',['../class_pet.html#a01c5ebaedb3d2bca8b09ec4573c85283',1,'Pet']]],
  ['architecture_5fid_1',['ARCHITECTURE_ID',['../_c_make_c_x_x_compiler_id_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCXXCompilerId.cpp']]]
];
