var searchData=
[
  ['getname_0',['getName',['../class_pet.html#a066c9ddca46eb39bca419f800efdc4ee',1,'Pet']]],
  ['getstatus_1',['getStatus',['../class_pet.html#a8a995fa419bf922fa4174b6f798094ac',1,'Pet']]],
  ['gettype_2',['getType',['../class_cat.html#af3965d0724f240c8c67116239de9cdc2',1,'Cat::getType()'],['../class_dog.html#a6b4cea25920cceeb642f6b5c11634a49',1,'Dog::getType()'],['../class_frog.html#aa36606dc69241b3c675d4f7dfbee3da5',1,'Frog::getType()'],['../class_orange.html#a526324a89dafbebd51a02de2fa63e5fd',1,'Orange::getType()'],['../class_pet.html#ad2570e600e54f9417587d6b4af5ce65e',1,'Pet::getType()']]]
];
