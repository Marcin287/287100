var searchData=
[
  ['splashscreen_2ecpp_0',['splashscreen.cpp',['../splashscreen_8cpp.html',1,'']]],
  ['splashscreen_2eh_1',['splashscreen.h',['../splashscreen_8h.html',1,'']]]
];
