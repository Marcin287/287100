var searchData=
[
  ['savepetstate_0',['savePetState',['../class_pet_room_widget.html#a3005c3e1fae9dd219e225d08077effdd',1,'PetRoomWidget']]],
  ['setage_1',['setAge',['../class_pet.html#a3969edc01a31c2e2c012444de8c952c7',1,'Pet']]],
  ['setclean_2',['setClean',['../class_pet.html#a5e7c5ea3ea5862267ea128dfb7674a84',1,'Pet']]],
  ['setenergy_3',['setEnergy',['../class_pet.html#ae5be442cd8d54f9d6fff0fc78c6ed639',1,'Pet']]],
  ['sethappy_4',['setHappy',['../class_pet.html#a3e93cd86c5ea94cca1db9f4d8692f316',1,'Pet']]],
  ['sethunger_5',['setHunger',['../class_pet.html#a3b8c005b735c35ef4d719db642e3d443',1,'Pet']]],
  ['setname_6',['setName',['../class_pet.html#a6a837e79decfc666593f58d2535f0e16',1,'Pet']]],
  ['setpet_7',['setPet',['../class_pet_room_widget.html#a868c00a1861f13124414c92b2758c8a9',1,'PetRoomWidget']]],
  ['setroom_8',['setRoom',['../class_pet_room_widget.html#a3ae4afb1e5dc4fb94841315bbedc3066',1,'PetRoomWidget']]],
  ['setstyle_9',['setStyle',['../class_pet_room_widget.html#a08c057db64dcecff99e962527ec619c2',1,'PetRoomWidget']]],
  ['setupui_10',['setupUi',['../class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58',1,'Ui_MainWindow']]],
  ['shownextpet_11',['showNextPet',['../class_choose_pet_widget.html#ad3be318175d92afb37c8631556f59fa5',1,'ChoosePetWidget']]],
  ['showpreviouspet_12',['showPreviousPet',['../class_choose_pet_widget.html#a956026c454c6bbdc5760bd13099f4563',1,'ChoosePetWidget']]],
  ['sleep_13',['sleep',['../class_cat.html#a8e6f4cbb9306c5c16a2f3c7e9c7ac8e4',1,'Cat::sleep()'],['../class_dog.html#a9670535c549881f9ff6925adb351f6cf',1,'Dog::sleep()'],['../class_frog.html#a0ff33aa3a02c0e3a3e2f0ba11f162985',1,'Frog::sleep()'],['../class_orange.html#ae3772aa9cc0eea84a12b7a03344997d3',1,'Orange::sleep()'],['../class_pet.html#aaed55a9d5b0542834e351cbf2fc45ecf',1,'Pet::sleep()']]],
  ['splashscreen_14',['SplashScreen',['../class_splash_screen.html#a20e1a6bc7b747c5d75d6de77ffdcbb81',1,'SplashScreen']]]
];
