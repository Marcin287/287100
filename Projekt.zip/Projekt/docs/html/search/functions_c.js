var searchData=
[
  ['updatepet_0',['updatePet',['../class_choose_pet_widget.html#af96cf777a0dfc376f2b74b91cd92012d',1,'ChoosePetWidget']]],
  ['updatestats_1',['updateStats',['../class_pet.html#a83b5696b8d86b49beb05f714ee8b3d78',1,'Pet']]]
];
