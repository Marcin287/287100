var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuw~",
  1: "cdfmopqsu",
  2: "qu",
  3: "cdfmopqsu",
  4: "cdfgilmopqrsu~",
  5: "abcefhilmnprst",
  6: "ps",
  7: "_acdhmpqsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Macros"
};

