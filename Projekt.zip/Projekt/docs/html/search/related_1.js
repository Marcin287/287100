var searchData=
[
  ['splashscreen_0',['SplashScreen',['../class_choose_pet_widget.html#a28b5aea6ffe82c2ff0054fd1c77d8c8e',1,'ChoosePetWidget::SplashScreen()'],['../class_pet_room_widget.html#a28b5aea6ffe82c2ff0054fd1c77d8c8e',1,'PetRoomWidget::SplashScreen()']]]
];
