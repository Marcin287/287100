var searchData=
[
  ['unicode_0',['UNICODE',['../moc__predefs_8h.html#a09ecca53f2cd1b8d1c566bedb245e141',1,'moc_predefs.h']]]
];
