var dir_19572e210953950637ab0e0bc42e961a =
[
    [ "CMakeFiles", "dir_babcaa7d183ac708ed65176601316ab1.html", "dir_babcaa7d183ac708ed65176601316ab1" ],
    [ "Tamagotchi_autogen", "dir_6ad5ee044c453d9f8d05386f8a2c4b10.html", "dir_6ad5ee044c453d9f8d05386f8a2c4b10" ]
];