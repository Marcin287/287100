# Projekt Tamagotchi – Wirtualny Zwierzak

## Opis projektu

**Projekt Tamagotchi** to aplikacja napisana w języku **C++** z użyciem biblioteki **Qt**, która symuluje opiekę nad wirtualnym zwierzakiem. Użytkownik może karmić, bawić się, usypiać oraz monitorować stan zdrowia i samopoczucia swojego pupila. Aplikacja posiada intuicyjny interfejs graficzny z kilkoma pokojami i animowanymi ikonami reprezentującymi czynności.

---

## Założenia funkcjonalne

- Możliwość tworzenia i opieki nad wirtualnym zwierzakiem (Tamagotchi)
- Zwierzak posiada podstawowe parametry:
  - **Głód**
  - **Energia**
  - **Czystość**
  - **Szczęście**
- Użytkownik może wykonywać akcje:
  - **Karmić**
  - **Bawić się**
  - **Usypiać**
  - **Myć**
- Parametry zwierzaka zmieniają się dynamicznie w czasie (np. wzrastający głód)
- Zwierzak **starzeje się** z upływem czasu
- Jeśli poziom **energii i głodu spadną do zera**, zwierzak **umiera**, a gra się kończy
- Interfejs graficzny:
  - Przejrzysty układ
  - Interaktywne przyciski
  - **Animowane ikony** odpowiadające czynnościom
- Kilka pomieszczeń:
  - Np. **pokój**, **kuchnia**, **sypialnia**
  - Możliwość przełączania się między nimi

---

## Założenia niefunkcjonalne

- Intuicyjny, prosty i estetyczny interfejs użytkownika
- Kod źródłowy:
  - Udokumentowany przy pomocy komentarzy **Doxygen**
  - Podzielony na pliki nagłówkowe (`.h`) i źródłowe (`.cpp`)

---

## Wymagania systemowe

- System operacyjny:
  - Windows  
- Minimalna pamięć RAM: 50 MB

---

## Instrukcja obsługi podstawowych funkcji

1. **Uruchomienie programu**  
   Po skompilowaniu i uruchomieniu aplikacji wyświetli się okno główne z ekranem ładowania, a następnie pojawi się widok wyboru zwierzaka.

2. **Wybór zwierzaka**  
   Na ekranie wyboru zwierzaka użytkownik może przeglądać dostępne zwierzaki za pomocą strzałek do zmiany. Po wybraniu zwierzaka należy kliknąć przycisk **Wybierz**, który otwiera pole do wpisania imienia zwierzaka.  
   Po wpisaniu imienia i naciśnięciu **Enter**, następuje przejście do pokoju zwierzaka.  
   Dodatkowo dostępny jest przycisk **Load**, który pozwala wczytać ostatni zapisany stan zwierzaka i od razu przenieść się do pokoju(stan zwierzaka zapisuje się co 5 sekund).

3. **Opieka nad zwierzakiem**  
   Po wyborze zwierzaka użytkownik zostaje przeniesiony do pokoju zwierzaka, gdzie może:
   - Karmić zwierzaka — przycisk zmniejsza głód
   - Bawić się ze zwierzakiem — poprawia nastrój
   - Usypiać zwierzaka — uzupełnia energię
   - Myć zwierzaka — poprawia czystość

4. **Przełączanie pomieszczeń**  
   Użytkownik może zmieniać pomieszczenia (np. kuchnia, sypialnia), klikając strzałki u góry ekranu.

5. **Monitorowanie stanu**  
   Aktualne wartości parametrów zwierzaka (głód, energia, nastrój, zdrowie) są wyświetlane na górze ekranu w postaci ikonek uzupełniających się na zielono zależnie od wartości parametru.

6. **Starzenie się i śmierć**  
   Zwierzak z czasem się starzeje. Jeżeli poziom **głodu** oraz **energii** spadną do zera, zwierzak **umiera**, a gra się kończy. 

---
